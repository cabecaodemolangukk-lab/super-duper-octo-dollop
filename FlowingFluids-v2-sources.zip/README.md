# FlowingFluids v2

Plugin para Purpur 1.21+ que replica o mod Flowing Fluids do Traben.

## Como compilar

### Pré-requisitos
- JDK 21
- Maven 3.6+

### Passos
1. Extraia este arquivo.
2. Abra um terminal na pasta extraída.
3. Execute:
   - **Windows**: `build.bat`
   - **Linux/macOS**: `chmod +x build.sh && ./build.sh`
4. O arquivo `.jar` estará em `target/FlowingFluids-2.0.0.jar`

## Instalação
Coloque o JAR na pasta `plugins` do seu servidor Purpur 1.21+ e reinicie.

## Configuração
O arquivo `config.yml` será gerado na primeira execução. Use `/ff reload` para recarregar.
