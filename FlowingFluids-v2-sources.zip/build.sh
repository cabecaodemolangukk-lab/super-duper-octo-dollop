#!/bin/bash
echo "Compilando FlowingFluids v2 com Maven..."
mvn clean package
if [ $? -ne 0 ]; then
    echo "Erro na compilação!"
    exit 1
fi
echo ""
echo "JAR gerado em target/FlowingFluids-2.0.0.jar"