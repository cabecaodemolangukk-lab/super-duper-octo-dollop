package com.grok.flowingfluids;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.MoistureChangeEvent;

public class FarmlandListener implements Listener {
    private final FlowingFluidsPlugin plugin;

    public FarmlandListener(FlowingFluidsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onMoistureChange(MoistureChangeEvent event) {
        if (!plugin.getConfigManager().enable) return;
        if (Math.random() > plugin.getConfigManager().farmlandDrainChance) return;

        Block farmland = event.getBlock();
        boolean hasWaterNearby = false;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                Block block = farmland.getRelative(dx, 0, dz);
                if (block.getType() == Material.WATER) {
                    hasWaterNearby = true;
                    break;
                }
            }
        }

        if (hasWaterNearby) {
            for (int dx = -4; dx <= 4; dx++) {
                for (int dz = -4; dz <= 4; dz++) {
                    Block water = farmland.getRelative(dx, 0, dz);
                    int level = plugin.getFluidManager().getCustomLevel(water);
                    if (level > 0) {
                        plugin.getFluidManager().setCustomLevel(water, level - 1);
                        return;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onBlockFade(BlockFadeEvent event) {
        // Pode ser expandido se necessário
    }
}