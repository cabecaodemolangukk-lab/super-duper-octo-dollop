package com.grok.flowingfluids;

import org.bukkit.NamespacedKey;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockBreakEvent;

public class FluidListener implements Listener {
    private final FlowingFluidsPlugin plugin;

    public FluidListener(FlowingFluidsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onFluidFlow(BlockFromToEvent event) {
        if (!plugin.getConfigManager().enable) return;
        plugin.getFluidManager().addToQueue(event.getBlock());
        plugin.getFluidManager().addToQueue(event.getToBlock());
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        if (!plugin.getConfigManager().enable) return;
        plugin.getFluidManager().addToQueue(event.getBlock().getRelative(0, 1, 0));
        plugin.getFluidManager().addToQueue(event.getBlock().getRelative(0, -1, 0));
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (!plugin.getConfigManager().enable) return;
        var block = event.getBlock();
        if (plugin.getFluidManager().getCustomLevel(block) > 0) {
            block.getPersistentDataContainer().remove(new NamespacedKey(plugin, "fluid_level"));
        }
    }
}