package com.grok.flowingfluids;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Animals;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityBreedEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ConsumptionListener implements Listener {
    private final FlowingFluidsPlugin plugin;

    public ConsumptionListener(FlowingFluidsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityBreed(EntityBreedEvent event) {
        if (!plugin.getConfigManager().enable) return;
        if (!(event.getMother() instanceof Animals)) return;
        if (Math.random() > plugin.getConfigManager().animalDrinkChance) return;

        Block center = event.getMother().getLocation().getBlock();
        for (int dx = -5; dx <= 5; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -5; dz <= 5; dz++) {
                    Block block = center.getRelative(dx, dy, dz);
                    int level = plugin.getFluidManager().getCustomLevel(block);
                    if (level > 0) {
                        plugin.getFluidManager().setCustomLevel(block, level - 1);
                        return;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (!plugin.getConfigManager().enable) return;
        Block block = event.getBlockClicked();
        int level = plugin.getFluidManager().getCustomLevel(block);
        if (level > 0) {
            plugin.getFluidManager().setCustomLevel(block, level - 1);
        }
    }

    @EventHandler
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        if (!plugin.getConfigManager().enable) return;
        Block block = event.getBlockClicked().getRelative(event.getBlockFace());
        plugin.getFluidManager().setCustomLevel(block, 8);
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (!plugin.getConfigManager().enable) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        ItemStack item = event.getItem();
        if (item == null || item.getType() != Material.GLASS_BOTTLE) return;
        Block clicked = event.getClickedBlock();
        if (clicked == null || clicked.getType() != Material.WATER) return;

        int level = plugin.getFluidManager().getCustomLevel(clicked);
        int required = plugin.getConfigManager().bottleConsumeLevels;

        if (level >= required) {
            plugin.getFluidManager().setCustomLevel(clicked, level - required);
            ItemStack waterBottle = new ItemStack(Material.POTION);
            ItemMeta meta = waterBottle.getItemMeta();
            if (meta != null) {
                meta.setDisplayName("§rÁgua Garrafa");
            }
            waterBottle.setItemMeta(meta);
            event.getPlayer().getInventory().setItemInMainHand(waterBottle);
            event.setCancelled(true);
        } else {
            event.getPlayer().sendMessage("§cA água está muito baixa para encher a garrafa.");
            event.setCancelled(true);
        }
    }
}