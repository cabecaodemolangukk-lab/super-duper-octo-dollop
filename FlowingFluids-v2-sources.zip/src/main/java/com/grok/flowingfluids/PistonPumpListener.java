package com.grok.flowingfluids;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import java.util.List;

public class PistonPumpListener implements Listener {
    private final FlowingFluidsPlugin plugin;

    public PistonPumpListener(FlowingFluidsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPistonExtend(BlockPistonExtendEvent event) {
        if (!plugin.getConfigManager().pistonPump) return;
        handlePistonMove(event.getBlocks(), event.getDirection());
    }

    @EventHandler
    public void onPistonRetract(BlockPistonRetractEvent event) {
        if (!plugin.getConfigManager().pistonPump) return;
        handlePistonMove(event.getBlocks(), event.getDirection());
    }

    private void handlePistonMove(List<Block> blocks, BlockFace direction) {
        FluidManager fm = plugin.getFluidManager();
        for (int i = blocks.size() - 1; i >= 0; i--) {
            Block block = blocks.get(i);
            if (block.getType() == Material.WATER || block.getType() == Material.LAVA) {
                Block target = block.getRelative(direction);
                int level = fm.getCustomLevel(block);
                if (target.getType() == Material.AIR) {
                    fm.setCustomLevel(target, level);
                    fm.setCustomLevel(block, 0);
                } else if (fm.getCustomLevel(target) > 0) {
                    int targetLevel = fm.getCustomLevel(target);
                    int combined = Math.min(8, targetLevel + level);
                    fm.setCustomLevel(target, combined);
                    fm.setCustomLevel(block, Math.max(0, targetLevel + level - 8));
                }
            }
        }
    }
}