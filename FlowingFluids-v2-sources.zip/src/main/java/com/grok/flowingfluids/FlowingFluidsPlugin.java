package com.grok.flowingfluids;

import org.bukkit.plugin.java.JavaPlugin;

public final class FlowingFluidsPlugin extends JavaPlugin {
    private static FlowingFluidsPlugin instance;
    private ConfigManager configManager;
    private FluidManager fluidManager;
    private int taskId;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        configManager = new ConfigManager(this);
        fluidManager = new FluidManager(this);

        getServer().getPluginManager().registerEvents(new FluidListener(this), this);
        getServer().getPluginManager().registerEvents(new PistonPumpListener(this), this);
        getServer().getPluginManager().registerEvents(new ConsumptionListener(this), this);
        getServer().getPluginManager().registerEvents(new FarmlandListener(this), this);
        getServer().getPluginManager().registerEvents(new ChunkListener(this), this);

        getCommand("ff").setExecutor(new CommandHandler(this));

        startTickTask();

        getLogger().info("§aFlowingFluids v2.0.0 carregado com sucesso!");
    }

    @Override
    public void onDisable() {
        if (taskId != -1) {
            getServer().getScheduler().cancelTask(taskId);
            taskId = -1;
        }
        fluidManager.saveAll();
    }

    public void reload() {
        configManager.load();
        reloadConfig();
        restartTickTask();
    }

    private void startTickTask() {
        taskId = getServer().getScheduler().runTaskTimer(this,
                () -> fluidManager.tickAll(), 0L, configManager.getTickDelay()).getTaskId();
    }

    private void restartTickTask() {
        if (taskId != -1) {
            getServer().getScheduler().cancelTask(taskId);
        }
        startTickTask();
    }

    public static FlowingFluidsPlugin get() { return instance; }
    public ConfigManager getConfigManager() { return configManager; }
    public FluidManager getFluidManager() { return fluidManager; }
}