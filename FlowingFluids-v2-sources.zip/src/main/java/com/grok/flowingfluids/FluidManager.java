package com.grok.flowingfluids;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Levelled;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;

public class FluidManager {
    private final FlowingFluidsPlugin plugin;
    private final Queue<Block> activeQueue = new LinkedList<>();
    private final NamespacedKey levelKey;
    private final Random random = new Random();

    public FluidManager(FlowingFluidsPlugin plugin) {
        this.plugin = plugin;
        this.levelKey = new NamespacedKey(plugin, "fluid_level");
    }

    public void tickAll() {
        ConfigManager cfg = plugin.getConfigManager();
        if (!cfg.enable) return;

        int processed = 0;
        while (!activeQueue.isEmpty() && processed < 200) {
            Block block = activeQueue.poll();
            if (block.isValid() && isFluid(block)) {
                processFluid(block);
            }
            processed++;
        }
    }

    public int getCustomLevel(Block block) {
        if (!isFluid(block)) return 0;
        Integer stored = block.getPersistentDataContainer().get(levelKey, PersistentDataType.INTEGER);
        if (stored != null) return stored;

        if (block.getBlockData() instanceof Levelled levelled) {
            int vanillaLevel = levelled.getLevel();
            return vanillaLevel == 0 ? 8 : 8 - vanillaLevel;
        }
        return 0;
    }

    public void setCustomLevel(Block block, int level) {
        if (level <= 0) {
            if (isFluid(block)) {
                block.setType(Material.AIR);
            }
            block.getPersistentDataContainer().remove(levelKey);
            return;
        }

        Material type;
        if (isFluid(block)) {
            type = block.getType();
        } else {
            type = Material.WATER;
        }

        if (level >= 8) {
            block.setType(type);
            if (block.getBlockData() instanceof Levelled levelled) {
                levelled.setLevel(0);
                block.setBlockData(levelled);
            }
            block.getPersistentDataContainer().set(levelKey, PersistentDataType.INTEGER, 8);
        } else {
            block.setType(type);
            if (block.getBlockData() instanceof Levelled levelled) {
                int vanillaLevel = 8 - level;
                levelled.setLevel(vanillaLevel);
                block.setBlockData(levelled);
            }
            block.getPersistentDataContainer().set(levelKey, PersistentDataType.INTEGER, level);
        }

        activeQueue.add(block);
    }

    private boolean isFluid(Block block) {
        Material type = block.getType();
        return type == Material.WATER || type == Material.LAVA;
    }

    private void processFluid(Block source) {
        int level = getCustomLevel(source);
        if (level <= 0) return;

        ConfigManager cfg = plugin.getConfigManager();

        if (cfg.isWorldBlacklisted(source.getWorld().getName())) return;

        Block down = source.getRelative(BlockFace.DOWN);
        if (canFlowInto(down)) {
            int downLevel = getCustomLevel(down);
            if (downLevel < 8) {
                int transfer = Math.min(level, 8 - downLevel);
                if (transfer > 0) {
                    setCustomLevel(down, downLevel + transfer);
                    setCustomLevel(source, level - transfer);
                }
                return;
            }
        }

        List<Block> sides = new ArrayList<>();
        for (BlockFace face : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            Block side = source.getRelative(face);
            if (canFlowInto(side) && getCustomLevel(side) < level - 1) {
                sides.add(side);
            }
        }

        if (!sides.isEmpty()) {
            Collections.shuffle(sides);
            int totalToSpread = Math.min(level, sides.size());
            if (totalToSpread > 0) {
                int each = Math.max(1, (int) (totalToSpread * cfg.levelingAggression / sides.size()));
                for (Block side : sides) {
                    int cur = getCustomLevel(side);
                    int add = Math.min(each, 8 - cur);
                    if (add > 0) {
                        setCustomLevel(side, cur + add);
                        level -= add;
                        if (level <= 0) {
                            setCustomLevel(source, 0);
                            return;
                        }
                    }
                }
                if (level > 0) {
                    setCustomLevel(source, level);
                } else {
                    setCustomLevel(source, 0);
                }
                return;
            }
        }

        double evapRate = source.getWorld().getEnvironment() == World.Environment.NETHER
                ? cfg.netherEvaporation : cfg.evaporationRate;
        if (random.nextDouble() < evapRate && level > 1) {
            setCustomLevel(source, level - 1);
            return;
        }

        if (source.getWorld().hasStorm() && source.getY() >= cfg.seaLevel
                && random.nextDouble() < cfg.rainRefillRate && level < 8) {
            setCustomLevel(source, level + 1);
            return;
        }

        if (cfg.infiniteOceanRiverSwamp && level < 8 && isInInfiniteBiome(source)) {
            if (source.getY() <= cfg.seaLevel && random.nextDouble() < 0.01) {
                setCustomLevel(source, level + 1);
            }
        }

        activeQueue.add(source);
    }

    private boolean canFlowInto(Block block) {
        Material type = block.getType();
        return type == Material.AIR || type == Material.WATER || type == Material.LAVA
                || type == Material.CAVE_AIR || type == Material.VOID_AIR;
    }

    private boolean isInInfiniteBiome(Block block) {
        var biome = block.getBiome();
        return biome == org.bukkit.block.Biome.OCEAN
                || biome == org.bukkit.block.Biome.DEEP_OCEAN
                || biome == org.bukkit.block.Biome.RIVER
                || biome == org.bukkit.block.Biome.SWAMP
                || biome == org.bukkit.block.Biome.MANGROVE_SWAMP;
    }

    public void addToQueue(Block block) {
        if (block != null && isFluid(block)) {
            activeQueue.add(block);
        }
    }

    public void saveAll() {}
}