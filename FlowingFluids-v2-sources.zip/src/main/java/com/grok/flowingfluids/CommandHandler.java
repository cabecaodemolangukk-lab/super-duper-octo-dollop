package com.grok.flowingfluids;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class CommandHandler implements CommandExecutor {
    private final FlowingFluidsPlugin plugin;

    public CommandHandler(FlowingFluidsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("flowingfluids.admin")) {
            sender.sendMessage("§cSem permissão!");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage("§b/ff reload §7- Recarrega a configuração");
            sender.sendMessage("§b/ff settings §7- Exibe as configurações atuais");
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            plugin.reload();
            sender.sendMessage("§aConfiguração recarregada com sucesso!");
            return true;
        }

        if (args[0].equalsIgnoreCase("settings")) {
            sender.sendMessage("§eConfigurações atuais:");
            sender.sendMessage("§7- Enable: §f" + plugin.getConfigManager().enable);
            sender.sendMessage("§7- Tick Delay: §f" + plugin.getConfigManager().tickDelay);
            sender.sendMessage("§7- Max Flow Distance: §f" + plugin.getConfigManager().maxFlowDistance);
            sender.sendMessage("§7- Leveling Aggression: §f" + plugin.getConfigManager().levelingAggression);
            sender.sendMessage("§7- Piston Pump: §f" + plugin.getConfigManager().pistonPump);
            sender.sendMessage("§7- Farmland Drain Chance: §f" + plugin.getConfigManager().farmlandDrainChance);
            sender.sendMessage("§7- Animal Drink Chance: §f" + plugin.getConfigManager().animalDrinkChance);
            sender.sendMessage("§7- Bottle Consume Levels: §f" + plugin.getConfigManager().bottleConsumeLevels);
            sender.sendMessage("§7- Hide Flowing Texture: §f" + plugin.getConfigManager().hideFlowingTexture);
            sender.sendMessage("§7- Evaporation Rate: §f" + plugin.getConfigManager().evaporationRate);
            sender.sendMessage("§7- Nether Evaporation: §f" + plugin.getConfigManager().netherEvaporation);
            sender.sendMessage("§7- Rain Refill Rate: §f" + plugin.getConfigManager().rainRefillRate);
            sender.sendMessage("§7- Infinite Ocean/River/Swamp: §f" + plugin.getConfigManager().infiniteOceanRiverSwamp);
            sender.sendMessage("§7- Sea Level: §f" + plugin.getConfigManager().seaLevel);
            sender.sendMessage("§7- Blacklisted Worlds: §f" + plugin.getConfigManager().blacklistedWorlds);
            sender.sendMessage("§7- Debug: §f" + plugin.getConfigManager().debug);
            return true;
        }

        return false;
    }
}