package com.grok.flowingfluids;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import java.util.HashSet;
import java.util.Set;

public class ConfigManager {
    private final JavaPlugin plugin;
    private final FileConfiguration cfg;

    public boolean enable = true;
    public int tickDelay = 2;
    public int maxFlowDistance = 7;
    public double levelingAggression = 1.0;
    public boolean pistonPump = true;
    public double farmlandDrainChance = 0.3;
    public double animalDrinkChance = 0.4;
    public int bottleConsumeLevels = 3;
    public boolean hideFlowingTexture = true;
    public double evaporationRate = 0.02;
    public double netherEvaporation = 0.25;
    public double rainRefillRate = 0.15;
    public boolean infiniteOceanRiverSwamp = true;
    public int seaLevel = 62;
    public Set<String> blacklistedWorlds = new HashSet<>();
    public boolean debug = false;

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.cfg = plugin.getConfig();
        loadDefaults();
        load();
    }

    private void loadDefaults() {
        cfg.addDefault("enable", true);
        cfg.addDefault("tick-delay", 2);
        cfg.addDefault("max-flow-distance", 7);
        cfg.addDefault("leveling-aggression", 1.0);
        cfg.addDefault("piston-pump", true);
        cfg.addDefault("farmland-drain-chance", 0.3);
        cfg.addDefault("animal-drink-chance", 0.4);
        cfg.addDefault("bottle-consume-levels", 3);
        cfg.addDefault("hide-flowing-texture", true);
        cfg.addDefault("evaporation-rate", 0.02);
        cfg.addDefault("nether-evaporation", 0.25);
        cfg.addDefault("rain-refill-rate", 0.15);
        cfg.addDefault("infinite-ocean-river-swamp", true);
        cfg.addDefault("sea-level", 62);
        cfg.addDefault("blacklisted-worlds", new String[]{});
        cfg.addDefault("debug", false);
        cfg.options().copyDefaults(true);
        plugin.saveConfig();
    }

    public void load() {
        enable = cfg.getBoolean("enable");
        tickDelay = cfg.getInt("tick-delay");
        maxFlowDistance = cfg.getInt("max-flow-distance");
        levelingAggression = cfg.getDouble("leveling-aggression");
        pistonPump = cfg.getBoolean("piston-pump");
        farmlandDrainChance = cfg.getDouble("farmland-drain-chance");
        animalDrinkChance = cfg.getDouble("animal-drink-chance");
        bottleConsumeLevels = cfg.getInt("bottle-consume-levels");
        hideFlowingTexture = cfg.getBoolean("hide-flowing-texture");
        evaporationRate = cfg.getDouble("evaporation-rate");
        netherEvaporation = cfg.getDouble("nether-evaporation");
        rainRefillRate = cfg.getDouble("rain-refill-rate");
        infiniteOceanRiverSwamp = cfg.getBoolean("infinite-ocean-river-swamp");
        seaLevel = cfg.getInt("sea-level");
        blacklistedWorlds = new HashSet<>(cfg.getStringList("blacklisted-worlds"));
        debug = cfg.getBoolean("debug");
    }

    public int getTickDelay() {
        return enable ? tickDelay : 20;
    }

    public boolean isWorldBlacklisted(String worldName) {
        return blacklistedWorlds.contains(worldName);
    }
}